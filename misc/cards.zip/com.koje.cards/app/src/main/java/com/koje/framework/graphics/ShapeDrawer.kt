package com.koje.framework.graphics

class ShapeDrawer() : Drawer() {

    override fun createVertexShader(): String {
        return ""
    }

    override fun createFragmentShader(): String {
        return ""
    }

    override fun init() {
    }
}