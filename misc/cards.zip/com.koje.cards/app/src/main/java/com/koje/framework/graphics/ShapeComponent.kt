package com.koje.framework.graphics


class ShapeComponent(surface: Surface) : Component(surface) {
}