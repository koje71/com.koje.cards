package com.koje.cards.data

class StackEntry(var stack: Stack, val name: String, val solution: String, var score: Int) {

}