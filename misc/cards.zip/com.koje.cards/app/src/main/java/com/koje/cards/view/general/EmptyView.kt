package com.koje.cards.view.general

import com.koje.framework.view.FrameLayoutBuilder


class EmptyView : FrameLayoutBuilder.Editor {

    override fun edit(target: FrameLayoutBuilder) {
    }
}

