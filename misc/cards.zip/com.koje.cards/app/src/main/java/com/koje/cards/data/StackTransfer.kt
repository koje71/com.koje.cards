package com.koje.cards.data

class StackTransfer(val name: String, val content: List<StackEntryStorage>)
