package com.koje.framework.view

object Anim {

    val none = Anim
    val fade = Anim
    val fromLeft = Anim
    val fromRight = Anim

}