package com.koje.cards.data

class StackEntryStorage(val a: String, val b: String, var c: Int) {

}