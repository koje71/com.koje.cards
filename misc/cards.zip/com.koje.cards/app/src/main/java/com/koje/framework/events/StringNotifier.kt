package com.koje.framework.events

open class StringNotifier(content: String) : com.koje.framework.events.Notifier<String>(content) {
}