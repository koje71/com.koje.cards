package com.koje.framework.view

interface ViewEditor<T> {

    fun edit(target: T)

}