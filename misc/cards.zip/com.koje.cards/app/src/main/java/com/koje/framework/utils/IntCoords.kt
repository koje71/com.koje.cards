package com.koje.framework.utils

class IntCoords {

    var x = 0
    var y = 0

}