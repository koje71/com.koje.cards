package com.koje.framework.utils

class State(val name: String) {
}